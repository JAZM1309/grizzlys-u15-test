#!/usr/bin/env python3
"""Young Grizzlys – Prüfsummen der App-Dateien eintragen (ab 1.39.0).

Die App lädt app.css, js/app.js, js/app-daten.js, spielplan.js und spielbericht.js mit einer
Prüfsumme im Namen (…?h=1a2b3c4d). So holt sich das Handy nur Dateien, die sich wirklich geändert
haben. Nach jeder Änderung an einer dieser Dateien im App-Ordner ausführen:

    python3 bauen.py            (im App-Ordner, oder: python3 bauen.py PFAD/ZUM/APP-ORDNER)

Trägt die neuen Prüfsummen in index.html und in die Liste CORE in sw.js ein.
"""
import hashlib, os, re, sys

ASSETS = ["app.css", "js/app-daten.js", "js/app.js", "spielplan.js", "spielbericht.js"]
root = sys.argv[1] if len(sys.argv) > 1 else os.path.dirname(os.path.abspath(__file__))
if not os.path.exists(os.path.join(root, "index.html")):
    root = os.getcwd()

def h(name):
    with open(os.path.join(root, name), "rb") as f:
        return hashlib.sha1(f.read()).hexdigest()[:8]

idx = open(os.path.join(root, "index.html"), encoding="utf-8").read()
sw = open(os.path.join(root, "sw.js"), encoding="utf-8").read()
for a in ASSETS:
    if not os.path.exists(os.path.join(root, a)):
        sys.exit("fehlt: " + a)
    neu = f"{a}?h={h(a)}"
    pat = re.compile(re.escape(a) + r"\?[hv]=[0-9A-Za-z.]+")
    if not pat.search(idx):
        sys.exit("in index.html nicht eingebunden: " + a)
    idx = pat.sub(neu, idx)
    if pat.search(sw):
        sw = pat.sub(neu, sw)
    else:
        sw = sw.replace('  "./index.html",\n', f'  "./index.html",\n  "./{neu}",\n', 1)
    print(f"{a:20s} {neu.split('=')[1]}")
open(os.path.join(root, "index.html"), "w", encoding="utf-8").write(idx)
open(os.path.join(root, "sw.js"), "w", encoding="utf-8").write(sw)
